Deze zip file bevat de bestanden landmask2020.tif en landmask2020.tfw ten behoeve van de methode beschreven in het rapport 'De Voedseldrukmonitor' (ter Bogt, 2026). 

Het tfw bestand is een 'World file' die de benodigde schaal- en rotatiefactoren bevat en de plaatsingsgegevens om het bijbehorende tif-bestand correct in je GIS weer te geven. Het tfw bestand bevat geen projectie gegevens.

Het bestand landmask2020.tif is een rasterbestand afgeleid van twee bestanden van het Centraal Bureau voor de Statistiek (CBS), namelijk de Wijk- en buurtkaart 2020 en het bestand bodemgebruik 2020.

Het bestand landmask2020.tif heeft een gridcelresolutie van 25x25 meter en toont Nederland conform de landsbegrenzing van de wijk- en buurtkaart 2020 van het Centraal Bureau voor de Statistiek (CBS), waarbij alle cellen die land vertegenwoordigen de waarde 1 hebben en alle cellen die water vertegenwoordigen (waterlichamen > 1 miljoen m2) of land buiten Nederland, geen waarde (NoData) hebben. De selectie en weglating van watercellen die deel uitmaken van aaneengesloten waterlichamen van minimaal 1 miljoen vierkante meter is gedaan op basis van de verschillende landgebruiksklassen water in het bestand bodemgebruik 2020 van het CBS (NBBG2020).

Voor beide bronbestanden de Wijk- en buurtkaart 2020 (CBS) en het bestand bodemgebruik 2020 (CBS) gelden een noodzakelijke bronvermelding naar het Centraal Bureau voor de Statistiek (CBS, 2020).


Referenties:

ter Bogt M., Waterlander W., Wagtendonk A., van de Kassteele J., van Waarde V., de Ruijter A. & Dijkstra C. (2026). 
De Voedseldrukmonitor: Een instrument om de (on)gezonde voedselomgeving in kaart te brengen voor beleidsdoeleinden. 
Amsterdam UMC. https://doi.org/10.5281/zenodo.23018076